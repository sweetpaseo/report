globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/h7gRX-wWxA77AAmgSzlyk/_buildManifest.js",
    "static/h7gRX-wWxA77AAmgSzlyk/_ssgManifest.js",
    "static/h7gRX-wWxA77AAmgSzlyk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/14p8zg-6cknxl.js",
    "static/chunks/1k59telq4e5_m.js",
    "static/chunks/3-vy9d-r6x73o.js",
    "static/chunks/16af8e201h93u.js",
    "static/chunks/turbopack-44yz6ntleey44.js"
  ]
};
