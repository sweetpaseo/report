1:"$Sreact.fragment"
2:I[62552,["/_next/static/chunks/16bl-s63jllru.js"],"ViewportBoundary"]
3:I[62552,["/_next/static/chunks/16bl-s63jllru.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, viewport-fit=cover"}],["$","meta","2",{"name":"theme-color","content":"#071329"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Website Health Report"}],["$","meta","1",{"name":"description","content":"Dashboard GSC dan Google Analytics yang mudah dipahami."}],["$","link","2",{"rel":"manifest","href":"/manifest.webmanifest"}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"h7gRX-wWxA77AAmgSzlyk"}
