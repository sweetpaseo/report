1:"$Sreact.fragment"
2:I[2065,["/_next/static/chunks/16bl-s63jllru.js","/_next/static/chunks/09c88-zgx5-v0.js","/_next/static/chunks/1vcyqona5m8by.js"],"DashboardApp"]
3:I[62552,["/_next/static/chunks/16bl-s63jllru.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/09c88-zgx5-v0.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/1vcyqona5m8by.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"h7gRX-wWxA77AAmgSzlyk"}
5:null
