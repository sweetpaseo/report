1:"$Sreact.fragment"
2:I[32866,["/_next/static/chunks/16bl-s63jllru.js"],"default"]
3:I[4788,["/_next/static/chunks/16bl-s63jllru.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"h7gRX-wWxA77AAmgSzlyk"}
