var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0n5q_42._.js")
R.c("server/chunks/ssr/03pt_next_dist_esm_build_templates_app-page_0s_6ire.js")
R.c("server/chunks/ssr/[root-of-the-server]__0rc5fyx._.js")
R.c("server/chunks/ssr/03pt_next_dist_1inu-du._.js")
R.c("server/chunks/ssr/03pt_next_dist_client_components_builtin_global-error_0x_x-6y.js")
R.c("server/chunks/ssr/0m6y__next-internal_server_app__global-error_page_actions_0rccil9.js")
R.m(6065)
module.exports=R.m(6065).exports
