var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__1l5lhm9._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_manifest_webmanifest_route_actions_02aa5kg.js")
R.m(59861)
module.exports=R.m(59861).exports
