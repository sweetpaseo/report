var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__10grf-m._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_dashboard_route_actions_06grs1v.js")
R.m(85548)
module.exports=R.m(85548).exports
