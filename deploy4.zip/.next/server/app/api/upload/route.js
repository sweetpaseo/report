var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__05r9glf._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/[root-of-the-server]__14mw8ea._.js")
R.c("server/chunks/[root-of-the-server]__133_s_h._.js")
R.c("server/chunks/03pt_next_06757yz._.js")
R.c("server/chunks/0juw_website-health-report__next-internal_server_app_api_upload_route_actions_1xl5geq.js")
R.m(89764)
module.exports=R.m(89764).exports
