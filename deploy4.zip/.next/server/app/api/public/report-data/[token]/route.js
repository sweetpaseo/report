var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/report-data/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__0g_e7s0._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_public_report-data_[token]_route_actions_15lao00.js")
R.m(20602)
module.exports=R.m(20602).exports
