var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/report/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__0m857-b._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_public_report_[token]_route_actions_19u0qhp.js")
R.m(65335)
module.exports=R.m(65335).exports
