var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/public/client/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__1tm64be._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_public_client_[token]_route_actions_1tz40t7.js")
R.m(29041)
module.exports=R.m(29041).exports
