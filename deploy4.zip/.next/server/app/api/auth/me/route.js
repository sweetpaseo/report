var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__04zjiqx._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/03pt_next_06757yz._.js")
R.c("server/chunks/0wqh_ebsite-health-report__next-internal_server_app_api_auth_me_route_actions_0vj7muk.js")
R.m(23347)
module.exports=R.m(23347).exports
