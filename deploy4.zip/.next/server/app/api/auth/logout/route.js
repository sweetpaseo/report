var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0w53nc9._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_auth_logout_route_actions_0fa5nd8.js")
R.m(29471)
module.exports=R.m(29471).exports
