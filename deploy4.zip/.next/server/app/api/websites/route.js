var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/route.js")
R.c("server/chunks/[root-of-the-server]__07rpn5m._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/03pt_zod_v4_classic_external_1rvdc6b.js")
R.c("server/chunks/[root-of-the-server]__133_s_h._.js")
R.c("server/chunks/03pt_next_06757yz._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_websites_route_actions_15wj4qp.js")
R.m(27379)
module.exports=R.m(27379).exports
