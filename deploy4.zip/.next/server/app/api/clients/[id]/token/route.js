var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/[id]/token/route.js")
R.c("server/chunks/[root-of-the-server]__0b6otkq._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_clients_[id]_token_route_actions_1jbvpbd.js")
R.m(268)
module.exports=R.m(268).exports
