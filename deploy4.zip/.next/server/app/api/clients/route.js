var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/route.js")
R.c("server/chunks/[root-of-the-server]__0im80mo._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/03pt_zod_v4_classic_external_1rvdc6b.js")
R.c("server/chunks/[root-of-the-server]__133_s_h._.js")
R.c("server/chunks/03pt_next_06757yz._.js")
R.c("server/chunks/0wqh_ebsite-health-report__next-internal_server_app_api_clients_route_actions_1awlksw.js")
R.m(83241)
module.exports=R.m(83241).exports
