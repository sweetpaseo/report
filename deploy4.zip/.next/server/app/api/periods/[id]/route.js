var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/periods/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__03-4l11._.js")
R.c("server/chunks/Desktop_antigravity_gr_website-health-report_lib_auth_ts_1zewfjp._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/03pt_next_06757yz._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_periods_[id]_route_actions_1whfhge.js")
R.m(10242)
module.exports=R.m(10242).exports
