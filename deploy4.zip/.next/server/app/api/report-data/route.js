var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/report-data/route.js")
R.c("server/chunks/[root-of-the-server]__19z2-s1._.js")
R.c("server/chunks/[root-of-the-server]__0me_8jh._.js")
R.c("server/chunks/0m6y__next-internal_server_app_api_report-data_route_actions_0k__nx7.js")
R.m(55942)
module.exports=R.m(55942).exports
