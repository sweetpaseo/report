1:"$Sreact.fragment"
3:I[62552,["/_next/static/chunks/16bl-s63jllru.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"h7gRX-wWxA77AAmgSzlyk"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
