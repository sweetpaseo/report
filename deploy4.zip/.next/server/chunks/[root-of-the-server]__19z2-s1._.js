module.exports=[93695,(e,t,i)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,i)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,i)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,i)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,i)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,i)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},2157,(e,t,i)=>{t.exports=e.x("node:fs",()=>require("node:fs"))},50227,(e,t,i)=>{t.exports=e.x("node:path",()=>require("node:path"))},75697,e=>{"use strict";var t=e.x("node:sqlite",()=>require("node:sqlite"),!0),i=e.i(2157),r=e.i(50227);let a=globalThis;function s(){return process.env.DATA_DIR||r.default.join(process.cwd(),"data")}e.s(["getDb",0,function(){if(a.__whrDb)return a.__whrDb;let e=s();i.default.mkdirSync(e,{recursive:!0});let n=new t.DatabaseSync(r.default.join(e,"website-health.db"));n.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      public_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS websites (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      domain TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      public_token TEXT NOT NULL UNIQUE,
      client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    -- Try to add the column if it doesn't exist (for existing DBs)
    -- Ignore error if column already exists
    PRAGMA foreign_keys = OFF;
    -- Note: ALTER TABLE ADD COLUMN is used for migrations in SQLite
    -- We'll run it in a separate try-catch block below.

    CREATE TABLE IF NOT EXISTS report_periods (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      period_label TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(website_id, period_start, period_end),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS report_uploads (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      report_period_id TEXT,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      file_format TEXT NOT NULL,
      source_type TEXT,
      checksum TEXT NOT NULL,
      status TEXT NOT NULL,
      warning_message TEXT,
      error_message TEXT,
      uploaded_at TEXT NOT NULL,
      processed_at TEXT,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_upload_checksum ON report_uploads(website_id, checksum);

    CREATE TABLE IF NOT EXISTS monthly_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      source_type TEXT NOT NULL,
      metric_key TEXT NOT NULL,
      metric_value REAL,
      PRIMARY KEY(website_id, report_period_id, source_type, metric_key),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      metric_date TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(website_id, report_period_id, search_type, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      query TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_gsc_queries_period ON gsc_queries(website_id, report_period_id);

    CREATE TABLE IF NOT EXISTS gsc_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      page TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      device TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      metric_date TEXT NOT NULL,
      active_users REAL,
      new_users REAL,
      engagement_seconds REAL,
      revenue REAL,
      PRIMARY KEY(website_id, report_period_id, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      sessions REAL NOT NULL DEFAULT 0,
      new_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      page_title TEXT NOT NULL,
      views REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      event_name TEXT NOT NULL,
      event_count REAL NOT NULL DEFAULT 0,
      key_event_count REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_countries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      country TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      appearance TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      city TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_device_models (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      model TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
  `);try{n.exec("ALTER TABLE websites ADD COLUMN client_id TEXT REFERENCES clients(id) ON DELETE SET NULL;")}catch(e){}try{n.exec("ALTER TABLE websites ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{n.exec("ALTER TABLE websites ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}try{n.exec("ALTER TABLE clients ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{n.exec("ALTER TABLE clients ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}for(let e of["gsc_queries","gsc_pages","gsc_devices","gsc_countries","gsc_appearance"])try{n.exec(`ALTER TABLE ${e} ADD COLUMN search_type TEXT NOT NULL DEFAULT 'web';`)}catch(e){}return a.__whrDb=n,n},"uploadsDirectory",0,function(){let e=r.default.join(s(),"uploads");return i.default.mkdirSync(e,{recursive:!0}),e}])},89887,e=>{"use strict";function t(e){let t={};for(let i of e)t[`${i.source_type}.${i.metric_key}`]=Number(i.metric_value||0);return t}function i(e,t,i,r){if(e.prepare(`SELECT 1 FROM ${r} WHERE website_id = ? AND report_period_id = ? LIMIT 1`).get(t,i))return i;let a=e.prepare(`SELECT t.report_period_id FROM ${r} t JOIN report_periods rp ON rp.id = t.report_period_id WHERE t.website_id = ? ORDER BY rp.period_start DESC LIMIT 1`).get(t);return a?.report_period_id||i}function r(e,t,a,s,n,E="web"){let o=i(e,t,a,s);return e.prepare(`SELECT ${n} AS name, clicks, impressions, ctr, average_position AS averagePosition FROM ${s} WHERE website_id = ? AND report_period_id = ? AND search_type = ? ORDER BY impressions DESC`).all(t,o,E)}function a(e,t,i){let r=e.prepare(`
    SELECT DISTINCT rp.id, rp.period_start, rp.period_end, rp.period_label
    FROM report_periods rp
    JOIN monthly_metrics mm ON mm.report_period_id = rp.id
    WHERE rp.website_id = ?
    ORDER BY rp.period_start DESC
  `).all(t);if(!r.length)return null;let a=r.find(e=>e.id===i)||r[0],s=r.findIndex(e=>e.id===a.id),n=s>=0?r[s+1]:void 0,E=new Date(a.period_end);return{periods:r,selected:a,previous:n,isPartialMonth:!Number.isNaN(E.getTime())&&E>new Date}}e.s(["getDashboard",0,function(e,s,n,E="web"){let o=e.prepare("SELECT * FROM websites WHERE id = ?").get(s);if(!o)return null;let d=a(e,s,n);if(!d)return{website:o,periods:[],empty:!0};let{periods:p,selected:T,previous:l,isPartialMonth:c}=d,_=e.prepare(`
    SELECT rp.period_start, rp.period_label, mm.source_type, mm.metric_key, mm.metric_value
    FROM monthly_metrics mm
    JOIN report_periods rp ON rp.id = mm.report_period_id
    WHERE rp.website_id = ?
  `).all(s),N=new Map;for(let e of _)N.has(e.period_start)||N.set(e.period_start,{periodStart:e.period_start,periodLabel:e.period_label,metrics:{}}),N.get(e.period_start).metrics[`${e.source_type}.${e.metric_key}`]=Number(e.metric_value||0);let u=[...N.values()].sort((e,t)=>e.periodStart.localeCompare(t.periodStart)).slice(-12),L=t(e.prepare("SELECT source_type, metric_key, metric_value FROM monthly_metrics WHERE website_id = ? AND report_period_id = ?").all(s,T.id)),R=l?t(e.prepare("SELECT source_type, metric_key, metric_value FROM monthly_metrics WHERE website_id = ? AND report_period_id = ?").all(s,l.id)):{},A="aigen"===E?"gsc-aigen":"gsc",g=Object.fromEntries([`${A}.impressions`,`${A}.clicks`,`${A}.ctr`,`${A}.average_position`,"ga.sessions","ga.active_users","ga.new_users","ga.page_views","ga.pages_per_session","ga.average_engagement_seconds","ga.click_to_chat","ga.chat_conversion_rate","ga.revenue"].map(e=>{var t,i;let r;return[e,(r=(t=L[e]||0)-(i=R[e]||0),{current:t,previous:i,absolute:r,percent:i?r/i*100:null})]})),O=e.prepare(`
    SELECT metric_date AS date, clicks, impressions, ctr, average_position AS averagePosition
    FROM gsc_daily_metrics WHERE website_id = ? AND report_period_id = ? AND search_type = ? ORDER BY metric_date
  `).all(s,T.id,E),m=e.prepare(`
    SELECT metric_date AS date, active_users AS activeUsers, new_users AS newUsers, engagement_seconds AS engagementSeconds
    FROM ga_daily_metrics WHERE website_id = ? AND report_period_id = ? ORDER BY metric_date
  `).all(s,T.id),D=e.prepare(`
    SELECT channel, sessions, new_users AS newUsers FROM ga_channels
    WHERE website_id = ? AND report_period_id = ? ORDER BY sessions DESC LIMIT 8
  `).all(s,T.id),C=i(e,s,T.id,"gsc_queries"),S=e.prepare(`
    SELECT query, clicks, impressions, ctr, average_position AS averagePosition
    FROM gsc_queries
    WHERE website_id = ? AND report_period_id = ? AND search_type = ?
      AND average_position BETWEEN 4 AND 10 AND impressions >= 10 AND ctr <= 0.05
    ORDER BY impressions DESC LIMIT 6
  `).all(s,C,E),b=e.prepare(`
    SELECT query, clicks, impressions, ctr, average_position AS averagePosition
    FROM gsc_queries WHERE website_id = ? AND report_period_id = ? AND search_type = ?
    ORDER BY impressions DESC LIMIT 10
  `).all(s,C,E),U=r(e,s,T.id,"gsc_devices","device",E).map(e=>({device:e.name,clicks:e.clicks,impressions:e.impressions,ctr:e.ctr,averagePosition:e.averagePosition})),h=r(e,s,T.id,"gsc_pages","page",E).map(e=>({page:e.name,clicks:e.clicks,impressions:e.impressions,ctr:e.ctr})).sort((e,t)=>t.clicks-e.clicks).slice(0,10),w=r(e,s,T.id,"gsc_countries","country",E),I=r(e,s,T.id,"gsc_appearance","appearance",E),F=e.prepare(`
    SELECT page_title AS title, views FROM ga_pages
    WHERE website_id = ? AND report_period_id = ? ORDER BY views DESC LIMIT 10
  `).all(s,T.id),k=e.prepare(`
    SELECT event_name AS name, event_count AS count, key_event_count AS keyCount
    FROM ga_events WHERE website_id = ? AND report_period_id = ? ORDER BY event_count DESC LIMIT 10
  `).all(s,T.id),v=e.prepare(`
    SELECT city, active_users AS activeUsers FROM ga_cities
    WHERE website_id = ? AND report_period_id = ? ORDER BY active_users DESC LIMIT 12
  `).all(s,T.id),y=e.prepare(`
    SELECT model, active_users AS activeUsers FROM ga_device_models
    WHERE website_id = ? AND report_period_id = ? ORDER BY active_users DESC LIMIT 12
  `).all(s,T.id),f=g[`${A}.impressions`].percent,x=g["ga.sessions"].percent,M=g["ga.click_to_chat"].percent,X=(L[`${A}.impressions`]||0)>0,Y=(L["ga.sessions"]||0)>0,P=[f,x,M].filter(e=>null!==e&&e>0).length,B=[],G=(e,t,i)=>{null===t||t>-10||B.push({severity:"critical",text:`${e} anjlok ${Math.abs(t).toFixed(1)}% dibanding bulan lalu — ${i}.`})};G("Tayangan Google",f,"visibilitas organik melemah"),G("Klik organik",g[`${A}.clicks`]?.percent??null,"traffic pencarian menurun"),G("Sesi website",x,"jumlah pengunjung menurun");let K=g[`${A}.ctr`];K&&null!==K.percent&&K.percent<=-20&&B.push({severity:"warning",text:`CTR Google turun ${Math.abs(K.percent).toFixed(1)}% — judul dan meta description kurang mengundang klik.`});let $=g[`${A}.average_position`];$&&null!==$.percent&&$.percent>=10&&B.push({severity:"warning",text:`Posisi rata-rata memburuk ${$.percent.toFixed(1)}% — halaman kehilangan peringkat.`});let H=O.slice().sort((e,t)=>e.date.localeCompare(t.date));if(H.length>=14){let e=e=>e.reduce((e,t)=>e+(t.impressions||0),0),t=e(H.slice(-7)),i=e(H.slice(-14,-7));if(i>0){let e=(t-i)/i*100;e<=-10?B.push({severity:"warning",text:`Tayangan 7 hari terakhir anjlok ${Math.abs(e).toFixed(1)}% dibanding 7 hari sebelumnya — sinyal penurunan baru.`}):e>=10&&B.push({severity:"positive",text:`Tayangan 7 hari terakhir naik ${e.toFixed(1)}% dibanding 7 hari sebelumnya — momentum positif baru.`})}}let q=h.find(e=>{try{return"/"===new URL(e.page).pathname}catch{return!1}}),j=L[`${A}.clicks`]?(q?.clicks||0)/L[`${A}.clicks`]*100:0,W=D.find(e=>/organic/i.test(e.channel))?.sessions||0,J=D.find(e=>/paid/i.test(e.channel))?.sessions||0,Q=L["ga.sessions"]||0,V=[null!==f&&f>10?`Tayangan Google naik ${f.toFixed(1)}%. Website semakin sering ditemukan.`:null,K&&null!==K.absolute&&K.absolute<0?`CTR Google turun ${Math.abs(100*K.absolute).toFixed(2)} poin. Judul dan deskripsi perlu diperkuat.`:null,Q&&W?`Organic Search menyumbang ${(W/Q*100).toFixed(1)}% dari sesi.`:null,j>50?`${j.toFixed(1)}% klik organik masih menuju homepage. Distribusi ke halaman layanan perlu ditingkatkan.`:null,Q&&J/Q>.5?`Traffic berbayar masih dominan sebesar ${(J/Q*100).toFixed(1)}% sesi.`:null].filter(Boolean),z=[];if(null!==f&&Math.abs(f)>=5){let e=f>0?"meningkat":"menurun";z.push(`Tayangan di Google ${e} ${Math.abs(f).toFixed(1)}% dibanding periode sebelumnya. ${f>0?"Momentum visibilitas ini positif dan layak dipertahankan dengan rutin memublikasikan konten berkualitas yang relevan dengan audiens.":"Penurunan ini perlu segera diselidiki — periksa halaman yang kehilangan peringkat dan pantau pergerakan kompetitor pada kata kunci inti."}`)}if(U.length){let e=U.reduce((e,t)=>e+(t.impressions||0),0);if(e>0){let t=[...U].sort((e,t)=>(t.impressions||0)-(e.impressions||0))[0],i=t.impressions/e*100;i>=50&&z.push(`Perangkat ${t.device} mendominasi dengan ${i.toFixed(0)}% dari total tayangan (${t.impressions.toLocaleString("id-ID")}). Audiens praktis bergantung pada perangkat tersebut — pastikan kecepatan muat dan pengalaman pengguna di sana sudah optimal karena hampir seluruh traffic bergantung padanya.`)}}if(w.length){let e=w.reduce((e,t)=>e+(t.impressions||0),0);if(e>0){let t=[...w].sort((e,t)=>(t.impressions||0)-(e.impressions||0))[0],i=t.impressions/e*100;i>=40&&z.push(`Audiens organik terkonsentrasi di ${t.name} (${i.toFixed(0)}% dari total tayangan). Ekspansi ke wilayah atau pasar lain dapat memperluas jangkauan trafik.`)}}if(h.length){let e=L[`${A}.clicks`]||0,t=h[0];e>0&&t.clicks/e>.4&&z.push(`Traffic organik terkonsentrasi pada satu halaman ("${function(e){try{let t=new URL(e).pathname;if("/"===t)return"Homepage";let i=t.split("/").filter(Boolean).pop()||"Homepage";return i.length>24?`${i.slice(0,24)}…`:i}catch{return e.length>24?`${e.slice(0,24)}…`:e}}(t.page)}" menyumbang ${(t.clicks/e*100).toFixed(0)}% dari seluruh klik). Ini menjadi titik rentan: bila halaman ini turun peringkat, trafik ikut anjlok. Sebarkan otoritas dengan internal link dan konten pendukung.`)}let Z=L[`${A}.average_position`]||0,ee=L[`${A}.ctr`]||0;Z>5&&ee<.05&&z.push(`Posisi rata-rata berada di ${Z.toFixed(1)} namun CTR hanya ${(100*ee).toFixed(2)}%. Artinya halaman sudah muncul di halaman pertama, namun judul dan meta description belum cukup mengundang klik. Optimasi snippet berpotensi menaikkan trafik tanpa harus naik peringkat.`),0===z.length&&z.push("Secara keseluruhan metrik utama relatif stabil untuk periode ini. Lanjutkan pemantauan bulanan agar tren dapat terdeteksi lebih awal dan keputusan dipimpin oleh data.");let et=[{label:"Google Search Console",status:X?"ok":"missing",detail:X?"Data tersedia dan terbaca.":"Belum ada data GSC."},{label:"Google Analytics",status:Y?"ok":"missing",detail:Y?"Data tersedia dan terbaca.":"Belum ada data GA."},{label:"Key Event GA4",status:k.some(e=>e.keyCount>0)?"ok":"warning",detail:k.some(e=>e.keyCount>0)?"Key event terdeteksi.":"Belum ada key event pada report."},{label:"Tracking Pendapatan",status:L["ga.revenue"]>0?"ok":"warning",detail:L["ga.revenue"]>0?"Pendapatan terdeteksi.":"Belum menghasilkan data."}];return{website:o,periods:p,selected:T,previous:l,isPartialMonth:c,metrics:L,comparisons:g,monthlySeries:u,trends:{gsc:O,ga:m},channels:D,opportunities:S,topQueries:b,topGscPages:h,devices:U,countries:w,appearances:I,topPages:F,events:k,topCities:v,deviceModels:y,analystNotes:z,status:X||Y?P>=2?"BERTUMBUH":0===P?"PERLU PERHATIAN":"STABIL":"DATA BELUM LENGKAP",anomalies:B,insights:V,dataQuality:et,empty:!1}},"getFullReportData",0,function(e,t,s,n="web"){let E=e.prepare("SELECT * FROM websites WHERE id = ?").get(t);if(!E)return null;let o=a(e,t,s);if(!o)return{website:E,periods:[],empty:!0};let{periods:d,selected:p,previous:T,isPartialMonth:l}=o,c=i(e,t,p.id,"gsc_queries"),_=e.prepare(`
    SELECT query, clicks, impressions, ctr, average_position AS averagePosition
    FROM gsc_queries WHERE website_id = ? AND report_period_id = ? AND search_type = ? ORDER BY impressions DESC LIMIT ?
  `).all(t,c,n,300),N=i(e,t,p.id,"gsc_pages"),u=e.prepare(`
    SELECT page, clicks, impressions, ctr, average_position AS averagePosition
    FROM gsc_pages WHERE website_id = ? AND report_period_id = ? AND search_type = ? ORDER BY impressions DESC LIMIT ?
  `).all(t,N,n,300),L=e.prepare(`
    SELECT page_title AS title, views FROM ga_pages WHERE website_id = ? AND report_period_id = ? ORDER BY views DESC LIMIT ?
  `).all(t,p.id,300),R=r(e,t,p.id,"gsc_devices","device",n),A=r(e,t,p.id,"gsc_countries","country",n),g=r(e,t,p.id,"gsc_appearance","appearance",n),O=e.prepare(`
    SELECT event_name AS name, event_count AS count, key_event_count AS keyCount
    FROM ga_events WHERE website_id = ? AND report_period_id = ? ORDER BY event_count DESC LIMIT ?
  `).all(t,p.id,300),m=e.prepare(`
    SELECT channel, sessions, new_users AS newUsers FROM ga_channels
    WHERE website_id = ? AND report_period_id = ? ORDER BY sessions DESC LIMIT ?
  `).all(t,p.id,300),D=e.prepare(`
    SELECT city, active_users AS activeUsers FROM ga_cities
    WHERE website_id = ? AND report_period_id = ? ORDER BY active_users DESC LIMIT ?
  `).all(t,p.id,300),C=e.prepare(`
    SELECT model, active_users AS activeUsers FROM ga_device_models
    WHERE website_id = ? AND report_period_id = ? ORDER BY active_users DESC LIMIT ?
  `).all(t,p.id,300);return{website:E,periods:d,selected:p,previous:T,isPartialMonth:l,selectedPeriod:p,queries:_,gscPages:u,pages:L,devices:R,countries:A,appearances:g,events:O,channels:m,cities:D,deviceModels:C,empty:!1}}])},55942,e=>{"use strict";var t=e.i(12681),i=e.i(4969),r=e.i(6631),a=e.i(17198),s=e.i(2198),n=e.i(10127),E=e.i(88327),o=e.i(88371),d=e.i(88506),p=e.i(51172),T=e.i(86217),l=e.i(69748),c=e.i(48689),_=e.i(50292),N=e.i(60005),u=e.i(93695);e.i(44915);var L=e.i(66645),R=e.i(49432),A=e.i(89887),g=e.i(75697);async function O(e){let t=new URL(e.url),i=t.searchParams.get("websiteId"),r=t.searchParams.get("periodId")||void 0;if(!i)return R.NextResponse.json({error:"websiteId wajib diisi."},{status:400});let a=(0,A.getFullReportData)((0,g.getDb)(),i,r);return a?R.NextResponse.json(a):R.NextResponse.json({error:"Website tidak ditemukan."},{status:404})}e.s(["GET",0,O],63202);var m=e.i(63202);let D=new t.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/report-data/route",pathname:"/api/report-data",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/antigravity/gr/website-health-report/app/api/report-data/route.ts",nextConfigOutput:"standalone",userland:m,...{}}),{workAsyncStorage:C,workUnitAsyncStorage:S,serverHooks:b}=D;async function U(e,t,r){r.requestMeta&&(0,a.setRequestMeta)(e,r.requestMeta),D.isDev&&(0,a.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let R="/api/report-data/route";R=R.replace(/\/index$/,"")||"/";let A=await D.prepare(e,t,{srcPage:R,multiZoneDraftMode:!1});if(!A)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:g,deploymentId:O,params:m,nextConfig:C,parsedUrl:S,isDraftMode:b,prerenderManifest:U,routerServerContext:h,isOnDemandRevalidate:w,revalidateOnlyGenerated:I,resolvedPathname:F,clientReferenceManifest:k,serverActionsManifest:v}=A,y=(0,E.normalizeAppPath)(R),f=!!(U.dynamicRoutes[y]||U.routes[F]),x=async()=>((null==h?void 0:h.render404)?await h.render404(e,t,S,!1):t.end("This page could not be found"),null);if(f&&!b){let e=!!U.routes[F],t=U.dynamicRoutes[y];if(t&&!1===t.fallback&&!e){if(C.adapterPath)return await x();throw new u.NoFallbackError}}let M=null;!f||D.isDev||b||(M="/index"===(M=F)?"/":M);let X=!0===D.isDev||!f,Y=f&&!X;v&&k&&(0,n.setManifestsSingleton)({page:R,clientReferenceManifest:k,serverActionsManifest:v});let P=e.method||"GET",B=(0,s.getTracer)(),G=B.getActiveScopeSpan(),K=!!(null==h?void 0:h.isWrappedByNextServer),$=!!(0,a.getRequestMeta)(e,"minimalMode"),H=(0,a.getRequestMeta)(e,"incrementalCache")||await D.getIncrementalCache(e,C,U,$);null==H||H.resetRequestCache(),globalThis.__incrementalCache=H;let q={params:m,previewProps:U.preview,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:X,incrementalCache:H,cacheLifeProfiles:C.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,i,r,a)=>D.onRequestError(e,t,r,a,h)},sharedContext:{buildId:g,deploymentId:O}},j=new o.NodeNextRequest(e),W=new o.NodeNextResponse(t),J=d.NextRequestAdapter.fromNodeNextRequest(j,(0,d.signalFromNodeResponse)(t));try{let a,n=async e=>D.handle(J,q).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let i=B.getRootSpanAttributes();if(!i)return;if(i.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${i.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=i.get("next.route");if(r){let t=`${P} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),a&&a!==e&&(a.setAttribute("http.route",r),a.updateName(t))}else e.updateName(`${P} ${R}`)}),E=async a=>{var s,E;let o=async({previousCacheEntry:i})=>{try{if(!$&&w&&I&&!i)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await n(a);e.fetchMetrics=q.renderOpts.fetchMetrics;let E=q.renderOpts.pendingWaitUntil;E&&r.waitUntil&&(r.waitUntil(E),E=void 0);let o=q.renderOpts.collectedTags;if(!f)return await (0,l.sendResponse)(j,W,s,q.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,c.toNodeOutgoingHttpHeaders)(s.headers);o&&(t[N.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let i=void 0!==q.renderOpts.collectedRevalidate&&!(q.renderOpts.collectedRevalidate>=N.INFINITE_CACHE)&&q.renderOpts.collectedRevalidate,r=void 0===q.renderOpts.collectedExpire||q.renderOpts.collectedExpire>=N.INFINITE_CACHE?void 0:q.renderOpts.collectedExpire;return{value:{kind:L.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:i,expire:r}}}}catch(t){throw(null==i?void 0:i.isStale)&&await D.onRequestError(e,t,{routerKind:"App Router",routePath:R,routeType:"route",revalidateReason:(0,T.getRevalidateReason)({isStaticGeneration:Y,isOnDemandRevalidate:w})},!1,h),t}},d=await D.handleResponse({req:e,nextConfig:C,cacheKey:M,routeKind:i.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:U,isRoutePPREnabled:!1,isOnDemandRevalidate:w,revalidateOnlyGenerated:I,responseGenerator:o,waitUntil:r.waitUntil,isMinimalMode:$});if(!f)return null;if((null==d||null==(s=d.value)?void 0:s.kind)!==L.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(E=d.value)?void 0:E.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});$||t.setHeader("x-nextjs-cache",w?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),b&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,c.fromNodeOutgoingHttpHeaders)(d.value.headers);return $&&f||p.delete(N.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,_.getCacheControlHeader)(d.cacheControl)),await (0,l.sendResponse)(j,W,new Response(d.value.body,{headers:p,status:d.value.status||200})),null};K&&G?await E(G):(a=B.getActiveScopeSpan(),await B.withPropagatedContext(e.headers,()=>B.trace(p.BaseServerSpan.handleRequest,{spanName:`${P} ${R}`,kind:s.SpanKind.SERVER,attributes:{"http.method":P,"http.target":e.url}},E),void 0,!K))}catch(t){if(t instanceof u.NoFallbackError||await D.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,T.getRevalidateReason)({isStaticGeneration:Y,isOnDemandRevalidate:w})},!1,h),f)throw t;return await (0,l.sendResponse)(j,W,new Response(null,{status:500})),null}}e.s(["handler",0,U,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:S})},"routeModule",0,D,"serverHooks",0,b,"workAsyncStorage",0,C,"workUnitAsyncStorage",0,S],55942)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__19z2-s1._.js.map