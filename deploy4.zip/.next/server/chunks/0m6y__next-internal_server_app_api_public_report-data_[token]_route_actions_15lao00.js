module.exports=[22997,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_public_report-data_%5Btoken%5D_route_actions_15lao00.js.map