module.exports=[86882,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_public_report_%5Btoken%5D_route_actions_19u0qhp.js.map