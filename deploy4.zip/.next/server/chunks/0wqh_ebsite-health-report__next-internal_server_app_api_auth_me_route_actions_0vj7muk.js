module.exports=[41700,(e,o,d)=>{}];

//# sourceMappingURL=0wqh_ebsite-health-report__next-internal_server_app_api_auth_me_route_actions_0vj7muk.js.map