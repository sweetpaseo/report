module.exports=[80263,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_periods_%5Bid%5D_route_actions_1whfhge.js.map