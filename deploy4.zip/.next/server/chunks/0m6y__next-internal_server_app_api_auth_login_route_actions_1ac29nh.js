module.exports=[10087,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_auth_login_route_actions_1ac29nh.js.map