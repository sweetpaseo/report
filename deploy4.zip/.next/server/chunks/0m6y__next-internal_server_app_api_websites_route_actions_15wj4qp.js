module.exports=[15696,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_websites_route_actions_15wj4qp.js.map