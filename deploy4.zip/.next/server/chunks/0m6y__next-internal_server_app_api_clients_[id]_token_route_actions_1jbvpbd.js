module.exports=[2683,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_clients_%5Bid%5D_token_route_actions_1jbvpbd.js.map