module.exports=[93695,(e,t,E)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,E)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,E)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},2157,(e,t,E)=>{t.exports=e.x("node:fs",()=>require("node:fs"))},50227,(e,t,E)=>{t.exports=e.x("node:path",()=>require("node:path"))},75697,e=>{"use strict";var t=e.x("node:sqlite",()=>require("node:sqlite"),!0),E=e.i(2157),r=e.i(50227);let i=globalThis;function s(){return process.env.DATA_DIR||r.default.join(process.cwd(),"data")}e.s(["getDb",0,function(){if(i.__whrDb)return i.__whrDb;let e=s();E.default.mkdirSync(e,{recursive:!0});let T=new t.DatabaseSync(r.default.join(e,"website-health.db"));T.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      public_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS websites (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      domain TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      public_token TEXT NOT NULL UNIQUE,
      client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    -- Try to add the column if it doesn't exist (for existing DBs)
    -- Ignore error if column already exists
    PRAGMA foreign_keys = OFF;
    -- Note: ALTER TABLE ADD COLUMN is used for migrations in SQLite
    -- We'll run it in a separate try-catch block below.

    CREATE TABLE IF NOT EXISTS report_periods (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      period_label TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(website_id, period_start, period_end),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS report_uploads (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      report_period_id TEXT,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      file_format TEXT NOT NULL,
      source_type TEXT,
      checksum TEXT NOT NULL,
      status TEXT NOT NULL,
      warning_message TEXT,
      error_message TEXT,
      uploaded_at TEXT NOT NULL,
      processed_at TEXT,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_upload_checksum ON report_uploads(website_id, checksum);

    CREATE TABLE IF NOT EXISTS monthly_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      source_type TEXT NOT NULL,
      metric_key TEXT NOT NULL,
      metric_value REAL,
      PRIMARY KEY(website_id, report_period_id, source_type, metric_key),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      metric_date TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(website_id, report_period_id, search_type, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      query TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_gsc_queries_period ON gsc_queries(website_id, report_period_id);

    CREATE TABLE IF NOT EXISTS gsc_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      page TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      device TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      metric_date TEXT NOT NULL,
      active_users REAL,
      new_users REAL,
      engagement_seconds REAL,
      revenue REAL,
      PRIMARY KEY(website_id, report_period_id, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      sessions REAL NOT NULL DEFAULT 0,
      new_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      page_title TEXT NOT NULL,
      views REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      event_name TEXT NOT NULL,
      event_count REAL NOT NULL DEFAULT 0,
      key_event_count REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_countries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      country TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      appearance TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      city TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_device_models (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      model TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
  `);try{T.exec("ALTER TABLE websites ADD COLUMN client_id TEXT REFERENCES clients(id) ON DELETE SET NULL;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}for(let e of["gsc_queries","gsc_pages","gsc_devices","gsc_countries","gsc_appearance"])try{T.exec(`ALTER TABLE ${e} ADD COLUMN search_type TEXT NOT NULL DEFAULT 'web';`)}catch(e){}return i.__whrDb=T,T},"uploadsDirectory",0,function(){let e=r.default.join(s(),"uploads");return E.default.mkdirSync(e,{recursive:!0}),e}])},22734,(e,t,E)=>{t.exports=e.x("fs",()=>require("fs"))},10242,e=>{"use strict";var t=e.i(12681),E=e.i(4969),r=e.i(6631),i=e.i(17198),s=e.i(2198),T=e.i(10127),o=e.i(88327),a=e.i(88371),d=e.i(88506),n=e.i(51172),N=e.i(86217),p=e.i(69748),L=e.i(48689),R=e.i(50292),_=e.i(60005),c=e.i(93695);e.i(44915);var l=e.i(66645),A=e.i(49432),O=e.i(75697),u=e.i(15609),U=e.i(18054),C=e.i(22734);async function D(e,{params:t}){let E=(await (0,u.cookies)()).get(U.SESSION_COOKIE)?.value;if("admin"!==await (0,U.verifySessionToken)(E))return A.NextResponse.json({error:"Unauthorized"},{status:403});let{id:r}=await t;if(!r)return A.NextResponse.json({error:"Missing periodId"},{status:400});let i=(0,O.getDb)(),s=i.prepare("SELECT id, storage_path FROM report_uploads WHERE report_period_id = ?").all(r);try{i.exec("BEGIN"),i.prepare("DELETE FROM gsc_daily_metrics WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM gsc_queries WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM gsc_pages WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM gsc_devices WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM gsc_countries WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM gsc_appearance WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_daily_metrics WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_channels WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_pages WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_events WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_cities WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM ga_device_models WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM monthly_metrics WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM report_uploads WHERE report_period_id = ?").run(r),i.prepare("DELETE FROM report_periods WHERE id = ?").run(r),i.exec("COMMIT")}catch(e){throw i.exec("ROLLBACK"),e}for(let e of s)try{C.default.existsSync(e.storage_path)&&C.default.unlinkSync(e.storage_path)}catch(t){console.error("Failed to delete file:",e.storage_path)}return A.NextResponse.json({ok:!0})}e.s(["DELETE",0,D,"runtime",0,"nodejs"],21385);var F=e.i(21385);let I=new t.AppRouteRouteModule({definition:{kind:E.RouteKind.APP_ROUTE,page:"/api/periods/[id]/route",pathname:"/api/periods/[id]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/antigravity/gr/website-health-report/app/api/periods/[id]/route.ts",nextConfigOutput:"standalone",userland:F,...{}}),{workAsyncStorage:S,workUnitAsyncStorage:w,serverHooks:g}=I;async function h(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),I.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let A="/api/periods/[id]/route";A=A.replace(/\/index$/,"")||"/";let O=await I.prepare(e,t,{srcPage:A,multiZoneDraftMode:!1});if(!O)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:u,deploymentId:U,params:C,nextConfig:D,parsedUrl:F,isDraftMode:S,prerenderManifest:w,routerServerContext:g,isOnDemandRevalidate:h,revalidateOnlyGenerated:b,resolvedPathname:X,clientReferenceManifest:x,serverActionsManifest:v}=O,m=(0,o.normalizeAppPath)(A),y=!!(w.dynamicRoutes[m]||w.routes[X]),f=async()=>((null==g?void 0:g.render404)?await g.render404(e,t,F,!1):t.end("This page could not be found"),null);if(y&&!S){let e=!!w.routes[X],t=w.dynamicRoutes[m];if(t&&!1===t.fallback&&!e){if(D.adapterPath)return await f();throw new c.NoFallbackError}}let M=null;!y||I.isDev||S||(M="/index"===(M=X)?"/":M);let Y=!0===I.isDev||!y,K=y&&!Y;v&&x&&(0,T.setManifestsSingleton)({page:A,clientReferenceManifest:x,serverActionsManifest:v});let k=e.method||"GET",G=(0,s.getTracer)(),P=G.getActiveScopeSpan(),q=!!(null==g?void 0:g.isWrappedByNextServer),B=!!(0,i.getRequestMeta)(e,"minimalMode"),H=(0,i.getRequestMeta)(e,"incrementalCache")||await I.getIncrementalCache(e,D,w,B);null==H||H.resetRequestCache(),globalThis.__incrementalCache=H;let j={params:C,previewProps:w.preview,renderOpts:{experimental:{authInterrupts:!!D.experimental.authInterrupts},cacheComponents:!!D.cacheComponents,supportsDynamicResponse:Y,incrementalCache:H,cacheLifeProfiles:D.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,E,r,i)=>I.onRequestError(e,t,r,i,g)},sharedContext:{buildId:u,deploymentId:U}},W=new a.NodeNextRequest(e),$=new a.NodeNextResponse(t),Q=d.NextRequestAdapter.fromNodeNextRequest(W,(0,d.signalFromNodeResponse)(t));try{let i,T=async e=>I.handle(Q,j).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let E=G.getRootSpanAttributes();if(!E)return;if(E.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${E.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=E.get("next.route");if(r){let t=`${k} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",r),i.updateName(t))}else e.updateName(`${k} ${A}`)}),o=async i=>{var s,o;let a=async({previousCacheEntry:E})=>{try{if(!B&&h&&b&&!E)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await T(i);e.fetchMetrics=j.renderOpts.fetchMetrics;let o=j.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let a=j.renderOpts.collectedTags;if(!y)return await (0,p.sendResponse)(W,$,s,j.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,L.toNodeOutgoingHttpHeaders)(s.headers);a&&(t[_.NEXT_CACHE_TAGS_HEADER]=a),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let E=void 0!==j.renderOpts.collectedRevalidate&&!(j.renderOpts.collectedRevalidate>=_.INFINITE_CACHE)&&j.renderOpts.collectedRevalidate,r=void 0===j.renderOpts.collectedExpire||j.renderOpts.collectedExpire>=_.INFINITE_CACHE?void 0:j.renderOpts.collectedExpire;return{value:{kind:l.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:E,expire:r}}}}catch(t){throw(null==E?void 0:E.isStale)&&await I.onRequestError(e,t,{routerKind:"App Router",routePath:A,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:K,isOnDemandRevalidate:h})},!1,g),t}},d=await I.handleResponse({req:e,nextConfig:D,cacheKey:M,routeKind:E.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:h,revalidateOnlyGenerated:b,responseGenerator:a,waitUntil:r.waitUntil,isMinimalMode:B});if(!y)return null;if((null==d||null==(s=d.value)?void 0:s.kind)!==l.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",h?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),S&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let n=(0,L.fromNodeOutgoingHttpHeaders)(d.value.headers);return B&&y||n.delete(_.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||n.get("Cache-Control")||n.set("Cache-Control",(0,R.getCacheControlHeader)(d.cacheControl)),await (0,p.sendResponse)(W,$,new Response(d.value.body,{headers:n,status:d.value.status||200})),null};q&&P?await o(P):(i=G.getActiveScopeSpan(),await G.withPropagatedContext(e.headers,()=>G.trace(n.BaseServerSpan.handleRequest,{spanName:`${k} ${A}`,kind:s.SpanKind.SERVER,attributes:{"http.method":k,"http.target":e.url}},o),void 0,!q))}catch(t){if(t instanceof c.NoFallbackError||await I.onRequestError(e,t,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:K,isOnDemandRevalidate:h})},!1,g),y)throw t;return await (0,p.sendResponse)(W,$,new Response(null,{status:500})),null}}e.s(["handler",0,h,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:w})},"routeModule",0,I,"serverHooks",0,g,"workAsyncStorage",0,S,"workUnitAsyncStorage",0,w],10242)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__03-4l11._.js.map