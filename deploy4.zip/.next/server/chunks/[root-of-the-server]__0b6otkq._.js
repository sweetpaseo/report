module.exports=[93695,(e,t,E)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,E)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,E)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},2157,(e,t,E)=>{t.exports=e.x("node:fs",()=>require("node:fs"))},50227,(e,t,E)=>{t.exports=e.x("node:path",()=>require("node:path"))},75697,e=>{"use strict";var t=e.x("node:sqlite",()=>require("node:sqlite"),!0),E=e.i(2157),r=e.i(50227);let i=globalThis;function s(){return process.env.DATA_DIR||r.default.join(process.cwd(),"data")}e.s(["getDb",0,function(){if(i.__whrDb)return i.__whrDb;let e=s();E.default.mkdirSync(e,{recursive:!0});let T=new t.DatabaseSync(r.default.join(e,"website-health.db"));T.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      public_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS websites (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      domain TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      public_token TEXT NOT NULL UNIQUE,
      client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    -- Try to add the column if it doesn't exist (for existing DBs)
    -- Ignore error if column already exists
    PRAGMA foreign_keys = OFF;
    -- Note: ALTER TABLE ADD COLUMN is used for migrations in SQLite
    -- We'll run it in a separate try-catch block below.

    CREATE TABLE IF NOT EXISTS report_periods (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      period_label TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(website_id, period_start, period_end),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS report_uploads (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      report_period_id TEXT,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      file_format TEXT NOT NULL,
      source_type TEXT,
      checksum TEXT NOT NULL,
      status TEXT NOT NULL,
      warning_message TEXT,
      error_message TEXT,
      uploaded_at TEXT NOT NULL,
      processed_at TEXT,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_upload_checksum ON report_uploads(website_id, checksum);

    CREATE TABLE IF NOT EXISTS monthly_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      source_type TEXT NOT NULL,
      metric_key TEXT NOT NULL,
      metric_value REAL,
      PRIMARY KEY(website_id, report_period_id, source_type, metric_key),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      metric_date TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(website_id, report_period_id, search_type, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      query TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_gsc_queries_period ON gsc_queries(website_id, report_period_id);

    CREATE TABLE IF NOT EXISTS gsc_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      page TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      device TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      metric_date TEXT NOT NULL,
      active_users REAL,
      new_users REAL,
      engagement_seconds REAL,
      revenue REAL,
      PRIMARY KEY(website_id, report_period_id, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      sessions REAL NOT NULL DEFAULT 0,
      new_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      page_title TEXT NOT NULL,
      views REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      event_name TEXT NOT NULL,
      event_count REAL NOT NULL DEFAULT 0,
      key_event_count REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_countries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      country TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      appearance TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      city TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_device_models (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      model TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
  `);try{T.exec("ALTER TABLE websites ADD COLUMN client_id TEXT REFERENCES clients(id) ON DELETE SET NULL;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}for(let e of["gsc_queries","gsc_pages","gsc_devices","gsc_countries","gsc_appearance"])try{T.exec(`ALTER TABLE ${e} ADD COLUMN search_type TEXT NOT NULL DEFAULT 'web';`)}catch(e){}return i.__whrDb=T,T},"uploadsDirectory",0,function(){let e=r.default.join(s(),"uploads");return E.default.mkdirSync(e,{recursive:!0}),e}])},66680,(e,t,E)=>{t.exports=e.x("node:crypto",()=>require("node:crypto"))},268,e=>{"use strict";var t=e.i(12681),E=e.i(4969),r=e.i(6631),i=e.i(17198),s=e.i(2198),T=e.i(10127),o=e.i(88327),a=e.i(88371),n=e.i(88506),d=e.i(51172),N=e.i(86217),L=e.i(69748),p=e.i(48689),R=e.i(50292),c=e.i(60005),l=e.i(93695);e.i(44915);var A=e.i(66645),_=e.i(66680),u=e.i(49432),O=e.i(75697),U=e.i(18054);async function C(e,{params:t}){let E=e.headers.get("cookie")?.match(/whr_session=([^;]+)/)?.[1];if("admin"!==await (0,U.verifySessionToken)(E))return u.NextResponse.json({error:"Akses ditolak"},{status:403});let{id:r}=await t,i=(0,O.getDb)();if(!i.prepare("SELECT id FROM clients WHERE id = ?").get(r))return u.NextResponse.json({error:"Klien tidak ditemukan."},{status:404});let s="c_"+_.default.randomBytes(24).toString("base64url");return i.prepare("UPDATE clients SET public_token = ?, public_token_revoked = 0, public_token_expires_at = NULL WHERE id = ?").run(s,r),u.NextResponse.json({publicToken:s})}async function D(e,{params:t}){let E=e.headers.get("cookie")?.match(/whr_session=([^;]+)/)?.[1];if("admin"!==await (0,U.verifySessionToken)(E))return u.NextResponse.json({error:"Akses ditolak"},{status:403});let{id:r}=await t,i=(0,O.getDb)();return i.prepare("SELECT id FROM clients WHERE id = ?").get(r)?(i.prepare("UPDATE clients SET public_token_revoked = 1 WHERE id = ?").run(r),u.NextResponse.json({ok:!0})):u.NextResponse.json({error:"Klien tidak ditemukan."},{status:404})}e.s(["DELETE",0,D,"POST",0,C],7690);var S=e.i(7690);let F=new t.AppRouteRouteModule({definition:{kind:E.RouteKind.APP_ROUTE,page:"/api/clients/[id]/token/route",pathname:"/api/clients/[id]/token",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/antigravity/gr/website-health-report/app/api/clients/[id]/token/route.ts",nextConfigOutput:"standalone",userland:S,...{}}),{workAsyncStorage:I,workUnitAsyncStorage:w,serverHooks:b}=F;async function h(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),F.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let _="/api/clients/[id]/token/route";_=_.replace(/\/index$/,"")||"/";let u=await F.prepare(e,t,{srcPage:_,multiZoneDraftMode:!1});if(!u)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:O,deploymentId:U,params:C,nextConfig:D,parsedUrl:S,isDraftMode:I,prerenderManifest:w,routerServerContext:b,isOnDemandRevalidate:h,revalidateOnlyGenerated:X,resolvedPathname:g,clientReferenceManifest:x,serverActionsManifest:m}=u,v=(0,o.normalizeAppPath)(_),y=!!(w.dynamicRoutes[v]||w.routes[g]),f=async()=>((null==b?void 0:b.render404)?await b.render404(e,t,S,!1):t.end("This page could not be found"),null);if(y&&!I){let e=!!w.routes[g],t=w.dynamicRoutes[v];if(t&&!1===t.fallback&&!e){if(D.adapterPath)return await f();throw new l.NoFallbackError}}let k=null;!y||F.isDev||I||(k="/index"===(k=g)?"/":k);let Y=!0===F.isDev||!y,M=y&&!Y;m&&x&&(0,T.setManifestsSingleton)({page:_,clientReferenceManifest:x,serverActionsManifest:m});let K=e.method||"GET",G=(0,s.getTracer)(),P=G.getActiveScopeSpan(),q=!!(null==b?void 0:b.isWrappedByNextServer),B=!!(0,i.getRequestMeta)(e,"minimalMode"),j=(0,i.getRequestMeta)(e,"incrementalCache")||await F.getIncrementalCache(e,D,w,B);null==j||j.resetRequestCache(),globalThis.__incrementalCache=j;let H={params:C,previewProps:w.preview,renderOpts:{experimental:{authInterrupts:!!D.experimental.authInterrupts},cacheComponents:!!D.cacheComponents,supportsDynamicResponse:Y,incrementalCache:j,cacheLifeProfiles:D.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,E,r,i)=>F.onRequestError(e,t,r,i,b)},sharedContext:{buildId:O,deploymentId:U}},$=new a.NodeNextRequest(e),W=new a.NodeNextResponse(t),Q=n.NextRequestAdapter.fromNodeNextRequest($,(0,n.signalFromNodeResponse)(t));try{let i,T=async e=>F.handle(Q,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let E=G.getRootSpanAttributes();if(!E)return;if(E.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${E.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=E.get("next.route");if(r){let t=`${K} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",r),i.updateName(t))}else e.updateName(`${K} ${_}`)}),o=async i=>{var s,o;let a=async({previousCacheEntry:E})=>{try{if(!B&&h&&X&&!E)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await T(i);e.fetchMetrics=H.renderOpts.fetchMetrics;let o=H.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let a=H.renderOpts.collectedTags;if(!y)return await (0,L.sendResponse)($,W,s,H.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);a&&(t[c.NEXT_CACHE_TAGS_HEADER]=a),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let E=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,r=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=c.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:E,expire:r}}}}catch(t){throw(null==E?void 0:E.isStale)&&await F.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,b),t}},n=await F.handleResponse({req:e,nextConfig:D,cacheKey:k,routeKind:E.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:h,revalidateOnlyGenerated:X,responseGenerator:a,waitUntil:r.waitUntil,isMinimalMode:B});if(!y)return null;if((null==n||null==(s=n.value)?void 0:s.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==n||null==(o=n.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",h?"REVALIDATED":n.isMiss?"MISS":n.isStale?"STALE":"HIT"),I&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,p.fromNodeOutgoingHttpHeaders)(n.value.headers);return B&&y||d.delete(c.NEXT_CACHE_TAGS_HEADER),!n.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,R.getCacheControlHeader)(n.cacheControl)),await (0,L.sendResponse)($,W,new Response(n.value.body,{headers:d,status:n.value.status||200})),null};q&&P?await o(P):(i=G.getActiveScopeSpan(),await G.withPropagatedContext(e.headers,()=>G.trace(d.BaseServerSpan.handleRequest,{spanName:`${K} ${_}`,kind:s.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},o),void 0,!q))}catch(t){if(t instanceof l.NoFallbackError||await F.onRequestError(e,t,{routerKind:"App Router",routePath:v,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,b),y)throw t;return await (0,L.sendResponse)($,W,new Response(null,{status:500})),null}}e.s(["handler",0,h,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:I,workUnitAsyncStorage:w})},"routeModule",0,F,"serverHooks",0,b,"workAsyncStorage",0,I,"workUnitAsyncStorage",0,w],268)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0b6otkq._.js.map