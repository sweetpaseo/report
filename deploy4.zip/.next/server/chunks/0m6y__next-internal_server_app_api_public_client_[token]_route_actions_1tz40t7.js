module.exports=[86624,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_public_client_%5Btoken%5D_route_actions_1tz40t7.js.map