module.exports=[93695,(e,t,E)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,E)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,E)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,E)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},2157,(e,t,E)=>{t.exports=e.x("node:fs",()=>require("node:fs"))},50227,(e,t,E)=>{t.exports=e.x("node:path",()=>require("node:path"))},75697,e=>{"use strict";var t=e.x("node:sqlite",()=>require("node:sqlite"),!0),E=e.i(2157),r=e.i(50227);let i=globalThis;function s(){return process.env.DATA_DIR||r.default.join(process.cwd(),"data")}e.s(["getDb",0,function(){if(i.__whrDb)return i.__whrDb;let e=s();E.default.mkdirSync(e,{recursive:!0});let T=new t.DatabaseSync(r.default.join(e,"website-health.db"));T.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      public_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS websites (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      domain TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      public_token TEXT NOT NULL UNIQUE,
      client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    -- Try to add the column if it doesn't exist (for existing DBs)
    -- Ignore error if column already exists
    PRAGMA foreign_keys = OFF;
    -- Note: ALTER TABLE ADD COLUMN is used for migrations in SQLite
    -- We'll run it in a separate try-catch block below.

    CREATE TABLE IF NOT EXISTS report_periods (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      period_label TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(website_id, period_start, period_end),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS report_uploads (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      report_period_id TEXT,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      file_format TEXT NOT NULL,
      source_type TEXT,
      checksum TEXT NOT NULL,
      status TEXT NOT NULL,
      warning_message TEXT,
      error_message TEXT,
      uploaded_at TEXT NOT NULL,
      processed_at TEXT,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_upload_checksum ON report_uploads(website_id, checksum);

    CREATE TABLE IF NOT EXISTS monthly_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      source_type TEXT NOT NULL,
      metric_key TEXT NOT NULL,
      metric_value REAL,
      PRIMARY KEY(website_id, report_period_id, source_type, metric_key),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      metric_date TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(website_id, report_period_id, search_type, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      query TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_gsc_queries_period ON gsc_queries(website_id, report_period_id);

    CREATE TABLE IF NOT EXISTS gsc_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      page TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      device TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      metric_date TEXT NOT NULL,
      active_users REAL,
      new_users REAL,
      engagement_seconds REAL,
      revenue REAL,
      PRIMARY KEY(website_id, report_period_id, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      sessions REAL NOT NULL DEFAULT 0,
      new_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      page_title TEXT NOT NULL,
      views REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      event_name TEXT NOT NULL,
      event_count REAL NOT NULL DEFAULT 0,
      key_event_count REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_countries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      country TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      appearance TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      city TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_device_models (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      model TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
  `);try{T.exec("ALTER TABLE websites ADD COLUMN client_id TEXT REFERENCES clients(id) ON DELETE SET NULL;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}for(let e of["gsc_queries","gsc_pages","gsc_devices","gsc_countries","gsc_appearance"])try{T.exec(`ALTER TABLE ${e} ADD COLUMN search_type TEXT NOT NULL DEFAULT 'web';`)}catch(e){}return i.__whrDb=T,T},"uploadsDirectory",0,function(){let e=r.default.join(s(),"uploads");return E.default.mkdirSync(e,{recursive:!0}),e}])},66680,(e,t,E)=>{t.exports=e.x("node:crypto",()=>require("node:crypto"))},83241,e=>{"use strict";var t=e.i(12681),E=e.i(4969),r=e.i(6631),i=e.i(17198),s=e.i(2198),T=e.i(10127),a=e.i(88327),o=e.i(88371),n=e.i(88506),N=e.i(51172),d=e.i(86217),L=e.i(69748),p=e.i(48689),R=e.i(50292),c=e.i(60005),l=e.i(93695);e.i(44915);var A=e.i(66645),_=e.i(66680),O=e.i(15609),u=e.i(49432),U=e.i(42690),C=e.i(75697),D=e.i(18054);let S=U.z.object({name:U.z.string().trim().min(2).max(100)});async function I(){let e=(await (0,O.cookies)()).get(D.SESSION_COOKIE)?.value;if("admin"!==await (0,D.verifySessionToken)(e))return u.NextResponse.json({error:"Akses ditolak"},{status:403});let t=(0,C.getDb)().prepare(`
    SELECT c.*,
      (SELECT COUNT(*) FROM websites w WHERE w.client_id = c.id) AS website_count
    FROM clients c ORDER BY c.created_at DESC
  `).all();return u.NextResponse.json({clients:t})}async function F(e){let t=(await (0,O.cookies)()).get(D.SESSION_COOKIE)?.value;if("admin"!==await (0,D.verifySessionToken)(t))return u.NextResponse.json({error:"Hanya administrator yang dapat menambah klien."},{status:403});let E=S.safeParse(await e.json().catch(()=>null));if(!E.success)return u.NextResponse.json({error:"Nama klien tidak valid."},{status:400});let r=_.default.randomUUID(),i="c_"+_.default.randomBytes(24).toString("base64url");return(0,C.getDb)().prepare(`
    INSERT INTO clients(id, name, public_token, created_at)
    VALUES (?, ?, ?, ?)
  `).run(r,E.data.name,i,new Date().toISOString()),u.NextResponse.json({id:r,publicToken:i},{status:201})}e.s(["GET",0,I,"POST",0,F],9984);var w=e.i(9984);let b=new t.AppRouteRouteModule({definition:{kind:E.RouteKind.APP_ROUTE,page:"/api/clients/route",pathname:"/api/clients",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/antigravity/gr/website-health-report/app/api/clients/route.ts",nextConfigOutput:"standalone",userland:w,...{}}),{workAsyncStorage:h,workUnitAsyncStorage:X,serverHooks:g}=b;async function m(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),b.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let _="/api/clients/route";_=_.replace(/\/index$/,"")||"/";let O=await b.prepare(e,t,{srcPage:_,multiZoneDraftMode:!1});if(!O)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:u,deploymentId:U,params:C,nextConfig:D,parsedUrl:S,isDraftMode:I,prerenderManifest:F,routerServerContext:w,isOnDemandRevalidate:h,revalidateOnlyGenerated:X,resolvedPathname:g,clientReferenceManifest:m,serverActionsManifest:x}=O,v=(0,a.normalizeAppPath)(_),y=!!(F.dynamicRoutes[v]||F.routes[g]),f=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,S,!1):t.end("This page could not be found"),null);if(y&&!I){let e=!!F.routes[g],t=F.dynamicRoutes[v];if(t&&!1===t.fallback&&!e){if(D.adapterPath)return await f();throw new l.NoFallbackError}}let Y=null;!y||b.isDev||I||(Y="/index"===(Y=g)?"/":Y);let k=!0===b.isDev||!y,M=y&&!k;x&&m&&(0,T.setManifestsSingleton)({page:_,clientReferenceManifest:m,serverActionsManifest:x});let K=e.method||"GET",G=(0,s.getTracer)(),P=G.getActiveScopeSpan(),q=!!(null==w?void 0:w.isWrappedByNextServer),B=!!(0,i.getRequestMeta)(e,"minimalMode"),j=(0,i.getRequestMeta)(e,"incrementalCache")||await b.getIncrementalCache(e,D,F,B);null==j||j.resetRequestCache(),globalThis.__incrementalCache=j;let H={params:C,previewProps:F.preview,renderOpts:{experimental:{authInterrupts:!!D.experimental.authInterrupts},cacheComponents:!!D.cacheComponents,supportsDynamicResponse:k,incrementalCache:j,cacheLifeProfiles:D.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,E,r,i)=>b.onRequestError(e,t,r,i,w)},sharedContext:{buildId:u,deploymentId:U}},$=new o.NodeNextRequest(e),W=new o.NodeNextResponse(t),z=n.NextRequestAdapter.fromNodeNextRequest($,(0,n.signalFromNodeResponse)(t));try{let i,T=async e=>b.handle(z,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let E=G.getRootSpanAttributes();if(!E)return;if(E.get("next.span_type")!==N.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${E.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=E.get("next.route");if(r){let t=`${K} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",r),i.updateName(t))}else e.updateName(`${K} ${_}`)}),a=async i=>{var s,a;let o=async({previousCacheEntry:E})=>{try{if(!B&&h&&X&&!E)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await T(i);e.fetchMetrics=H.renderOpts.fetchMetrics;let a=H.renderOpts.pendingWaitUntil;a&&r.waitUntil&&(r.waitUntil(a),a=void 0);let o=H.renderOpts.collectedTags;if(!y)return await (0,L.sendResponse)($,W,s,H.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);o&&(t[c.NEXT_CACHE_TAGS_HEADER]=o),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let E=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,r=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=c.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:E,expire:r}}}}catch(t){throw(null==E?void 0:E.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,d.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,w),t}},n=await b.handleResponse({req:e,nextConfig:D,cacheKey:Y,routeKind:E.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:F,isRoutePPREnabled:!1,isOnDemandRevalidate:h,revalidateOnlyGenerated:X,responseGenerator:o,waitUntil:r.waitUntil,isMinimalMode:B});if(!y)return null;if((null==n||null==(s=n.value)?void 0:s.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==n||null==(a=n.value)?void 0:a.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",h?"REVALIDATED":n.isMiss?"MISS":n.isStale?"STALE":"HIT"),I&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let N=(0,p.fromNodeOutgoingHttpHeaders)(n.value.headers);return B&&y||N.delete(c.NEXT_CACHE_TAGS_HEADER),!n.cacheControl||t.getHeader("Cache-Control")||N.get("Cache-Control")||N.set("Cache-Control",(0,R.getCacheControlHeader)(n.cacheControl)),await (0,L.sendResponse)($,W,new Response(n.value.body,{headers:N,status:n.value.status||200})),null};q&&P?await a(P):(i=G.getActiveScopeSpan(),await G.withPropagatedContext(e.headers,()=>G.trace(N.BaseServerSpan.handleRequest,{spanName:`${K} ${_}`,kind:s.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},a),void 0,!q))}catch(t){if(t instanceof l.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:v,routeType:"route",revalidateReason:(0,d.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,w),y)throw t;return await (0,L.sendResponse)($,W,new Response(null,{status:500})),null}}e.s(["handler",0,m,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:h,workUnitAsyncStorage:X})},"routeModule",0,b,"serverHooks",0,g,"workAsyncStorage",0,h,"workUnitAsyncStorage",0,X],83241)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0im80mo._.js.map