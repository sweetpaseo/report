module.exports=[10181,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_websites_%5Bid%5D_token_route_actions_0_sor8n.js.map