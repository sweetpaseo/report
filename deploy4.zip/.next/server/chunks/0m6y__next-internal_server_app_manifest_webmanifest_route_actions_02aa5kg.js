module.exports=[44874,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_manifest_webmanifest_route_actions_02aa5kg.js.map