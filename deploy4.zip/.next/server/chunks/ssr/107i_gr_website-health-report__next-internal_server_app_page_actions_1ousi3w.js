module.exports=[8654,(a,b,c)=>{}];

//# sourceMappingURL=107i_gr_website-health-report__next-internal_server_app_page_actions_1ousi3w.js.map