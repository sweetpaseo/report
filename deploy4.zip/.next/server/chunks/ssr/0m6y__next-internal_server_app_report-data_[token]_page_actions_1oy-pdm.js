module.exports=[81650,(a,b,c)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_report-data_%5Btoken%5D_page_actions_1oy-pdm.js.map