module.exports=[68507,(a,b,c)=>{}];

//# sourceMappingURL=0juw_website-health-report__next-internal_server_app__not-found_page_actions_0ox5c7v.js.map