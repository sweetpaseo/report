module.exports=[36714,(a,b,c)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app__global-error_page_actions_0rccil9.js.map