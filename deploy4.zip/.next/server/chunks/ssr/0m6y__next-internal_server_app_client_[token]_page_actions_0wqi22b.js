module.exports=[68314,(a,b,c)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_client_%5Btoken%5D_page_actions_0wqi22b.js.map