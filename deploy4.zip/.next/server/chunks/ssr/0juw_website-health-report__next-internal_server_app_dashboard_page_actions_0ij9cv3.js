module.exports=[47644,(a,b,c)=>{}];

//# sourceMappingURL=0juw_website-health-report__next-internal_server_app_dashboard_page_actions_0ij9cv3.js.map