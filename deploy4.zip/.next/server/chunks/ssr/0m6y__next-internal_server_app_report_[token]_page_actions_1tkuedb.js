module.exports=[10539,(a,b,c)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_report_%5Btoken%5D_page_actions_1tkuedb.js.map