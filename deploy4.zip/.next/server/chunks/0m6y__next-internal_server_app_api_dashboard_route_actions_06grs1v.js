module.exports=[96984,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_dashboard_route_actions_06grs1v.js.map