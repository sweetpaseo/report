module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},2157,(e,t,r)=>{t.exports=e.x("node:fs",()=>require("node:fs"))},50227,(e,t,r)=>{t.exports=e.x("node:path",()=>require("node:path"))},75697,e=>{"use strict";var t=e.x("node:sqlite",()=>require("node:sqlite"),!0),r=e.i(2157),E=e.i(50227);let i=globalThis;function s(){return process.env.DATA_DIR||E.default.join(process.cwd(),"data")}e.s(["getDb",0,function(){if(i.__whrDb)return i.__whrDb;let e=s();r.default.mkdirSync(e,{recursive:!0});let T=new t.DatabaseSync(E.default.join(e,"website-health.db"));T.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      public_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS websites (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      domain TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta',
      public_token TEXT NOT NULL UNIQUE,
      client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    -- Try to add the column if it doesn't exist (for existing DBs)
    -- Ignore error if column already exists
    PRAGMA foreign_keys = OFF;
    -- Note: ALTER TABLE ADD COLUMN is used for migrations in SQLite
    -- We'll run it in a separate try-catch block below.

    CREATE TABLE IF NOT EXISTS report_periods (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      period_label TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(website_id, period_start, period_end),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS report_uploads (
      id TEXT PRIMARY KEY,
      website_id TEXT NOT NULL,
      report_period_id TEXT,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      file_format TEXT NOT NULL,
      source_type TEXT,
      checksum TEXT NOT NULL,
      status TEXT NOT NULL,
      warning_message TEXT,
      error_message TEXT,
      uploaded_at TEXT NOT NULL,
      processed_at TEXT,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS idx_upload_checksum ON report_uploads(website_id, checksum);

    CREATE TABLE IF NOT EXISTS monthly_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      source_type TEXT NOT NULL,
      metric_key TEXT NOT NULL,
      metric_value REAL,
      PRIMARY KEY(website_id, report_period_id, source_type, metric_key),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      metric_date TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(website_id, report_period_id, search_type, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      query TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_gsc_queries_period ON gsc_queries(website_id, report_period_id);

    CREATE TABLE IF NOT EXISTS gsc_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      page TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      device TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_daily_metrics (
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      metric_date TEXT NOT NULL,
      active_users REAL,
      new_users REAL,
      engagement_seconds REAL,
      revenue REAL,
      PRIMARY KEY(website_id, report_period_id, metric_date),
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_channels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      sessions REAL NOT NULL DEFAULT 0,
      new_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      page_title TEXT NOT NULL,
      views REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      event_name TEXT NOT NULL,
      event_count REAL NOT NULL DEFAULT 0,
      key_event_count REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_countries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      country TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS gsc_appearance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      search_type TEXT NOT NULL DEFAULT 'web',
      appearance TEXT NOT NULL,
      clicks REAL NOT NULL DEFAULT 0,
      impressions REAL NOT NULL DEFAULT 0,
      ctr REAL NOT NULL DEFAULT 0,
      average_position REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_cities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      city TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ga_device_models (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      website_id TEXT NOT NULL,
      report_period_id TEXT NOT NULL,
      model TEXT NOT NULL,
      active_users REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(website_id) REFERENCES websites(id) ON DELETE CASCADE,
      FOREIGN KEY(report_period_id) REFERENCES report_periods(id) ON DELETE CASCADE
    );
  `);try{T.exec("ALTER TABLE websites ADD COLUMN client_id TEXT REFERENCES clients(id) ON DELETE SET NULL;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE websites ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_expires_at TEXT;")}catch(e){}try{T.exec("ALTER TABLE clients ADD COLUMN public_token_revoked INTEGER NOT NULL DEFAULT 0;")}catch(e){}for(let e of["gsc_queries","gsc_pages","gsc_devices","gsc_countries","gsc_appearance"])try{T.exec(`ALTER TABLE ${e} ADD COLUMN search_type TEXT NOT NULL DEFAULT 'web';`)}catch(e){}return i.__whrDb=T,T},"uploadsDirectory",0,function(){let e=E.default.join(s(),"uploads");return r.default.mkdirSync(e,{recursive:!0}),e}])},61792,e=>{"use strict";let t=new Map;e.s(["checkPublicTokenRateLimit",0,function(e,r=Date.now()){let E=`pub:${e}`,i=t.get(E);return!i||r>i.resetAt?(t.set(E,{count:1,resetAt:r+6e4,lockedUntil:0}),{allowed:!0,retryAfterSeconds:0}):i.count>=60?{allowed:!1,retryAfterSeconds:Math.ceil((i.resetAt-r)/1e3)}:(i.count+=1,{allowed:!0,retryAfterSeconds:0})},"checkRateLimit",0,function(e,r=Date.now()){for(let[e,E]of t)r>E.resetAt&&r>E.lockedUntil&&t.delete(e);let E=t.get(e);return E?r<E.lockedUntil?{allowed:!1,retryAfterSeconds:Math.ceil((E.lockedUntil-r)/1e3)}:E.count>=5?(E.lockedUntil=r+9e5,{allowed:!1,retryAfterSeconds:Math.ceil(900)}):(E.count+=1,{allowed:!0,retryAfterSeconds:0}):(t.set(e,{count:1,resetAt:r+9e5,lockedUntil:0}),{allowed:!0,retryAfterSeconds:0})},"resetRateLimit",0,function(e){t.delete(e)}])},28010,e=>{"use strict";var t=e.i(75697);e.s(["resolveClientToken",0,function(e){let r=(0,t.getDb)().prepare("SELECT id, name, public_token_expires_at, public_token_revoked FROM clients WHERE public_token = ?").get(e);return!r||1===r.public_token_revoked||r.public_token_expires_at&&new Date(r.public_token_expires_at).getTime()<Date.now()?{valid:!1}:{valid:!0,id:r.id,name:r.name}},"resolveWebsiteToken",0,function(e){let r=(0,t.getDb)().prepare("SELECT id, name, public_token_expires_at, public_token_revoked FROM websites WHERE public_token = ?").get(e);return!r||1===r.public_token_revoked||r.public_token_expires_at&&new Date(r.public_token_expires_at).getTime()<Date.now()?{valid:!1}:{valid:!0,id:r.id,name:r.name}}])},29041,e=>{"use strict";var t=e.i(12681),r=e.i(4969),E=e.i(6631),i=e.i(17198),s=e.i(2198),T=e.i(10127),o=e.i(88327),a=e.i(88371),n=e.i(88506),d=e.i(51172),N=e.i(86217),L=e.i(69748),p=e.i(48689),l=e.i(50292),c=e.i(60005),R=e.i(93695);e.i(44915);var A=e.i(66645),_=e.i(49432),u=e.i(75697),O=e.i(28010),U=e.i(61792);async function C(e,{params:t}){let r,{token:E}=await t;if(!E)return _.NextResponse.json({error:"Token klien diperlukan."},{status:400});let i=(0,U.checkPublicTokenRateLimit)(`c:${E}`);if(!i.allowed)return _.NextResponse.json({error:"Terlalu banyak permintaan."},{status:429,headers:{"Retry-After":String(i.retryAfterSeconds)}});let s=(0,O.resolveClientToken)(E);if(!s.valid||!s.id)return _.NextResponse.json({error:"Klien tidak ditemukan."},{status:404});let T=new URL(e.url).searchParams.get("websiteId"),o=(0,u.getDb)();if(T){let e=o.prepare(`
      SELECT id, name, domain, public_token
      FROM websites WHERE client_id = ? AND id = ? ORDER BY name ASC
    `).get(s.id,T);r=e?[e]:[]}else r=o.prepare(`
      SELECT id, name, domain, public_token
      FROM websites WHERE client_id = ? ORDER BY name ASC
    `).all(s.id);return _.NextResponse.json({client:{id:s.id,name:s.name},websites:r})}e.s(["GET",0,C],13709);var D=e.i(13709);let S=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/public/client/[token]/route",pathname:"/api/public/client/[token]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Desktop/antigravity/gr/website-health-report/app/api/public/client/[token]/route.ts",nextConfigOutput:"standalone",userland:D,...{}}),{workAsyncStorage:b,workUnitAsyncStorage:w,serverHooks:F}=S;async function I(e,t,E){E.requestMeta&&(0,i.setRequestMeta)(e,E.requestMeta),S.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let _="/api/public/client/[token]/route";_=_.replace(/\/index$/,"")||"/";let u=await S.prepare(e,t,{srcPage:_,multiZoneDraftMode:!1});if(!u)return t.statusCode=400,t.end("Bad Request"),null==E.waitUntil||E.waitUntil.call(E,Promise.resolve()),null;let{buildId:O,deploymentId:U,params:C,nextConfig:D,parsedUrl:b,isDraftMode:w,prerenderManifest:F,routerServerContext:I,isOnDemandRevalidate:h,revalidateOnlyGenerated:g,resolvedPathname:m,clientReferenceManifest:X,serverActionsManifest:v}=u,x=(0,o.normalizeAppPath)(_),k=!!(F.dynamicRoutes[x]||F.routes[m]),f=async()=>((null==I?void 0:I.render404)?await I.render404(e,t,b,!1):t.end("This page could not be found"),null);if(k&&!w){let e=!!F.routes[m],t=F.dynamicRoutes[x];if(t&&!1===t.fallback&&!e){if(D.adapterPath)return await f();throw new R.NoFallbackError}}let y=null;!k||S.isDev||w||(y="/index"===(y=m)?"/":y);let Y=!0===S.isDev||!k,M=k&&!Y;v&&X&&(0,T.setManifestsSingleton)({page:_,clientReferenceManifest:X,serverActionsManifest:v});let K=e.method||"GET",G=(0,s.getTracer)(),P=G.getActiveScopeSpan(),q=!!(null==I?void 0:I.isWrappedByNextServer),B=!!(0,i.getRequestMeta)(e,"minimalMode"),j=(0,i.getRequestMeta)(e,"incrementalCache")||await S.getIncrementalCache(e,D,F,B);null==j||j.resetRequestCache(),globalThis.__incrementalCache=j;let H={params:C,previewProps:F.preview,renderOpts:{experimental:{authInterrupts:!!D.experimental.authInterrupts},cacheComponents:!!D.cacheComponents,supportsDynamicResponse:Y,incrementalCache:j,cacheLifeProfiles:D.cacheLife,waitUntil:E.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,E,i)=>S.onRequestError(e,t,E,i,I)},sharedContext:{buildId:O,deploymentId:U}},$=new a.NodeNextRequest(e),W=new a.NodeNextResponse(t),Q=n.NextRequestAdapter.fromNodeNextRequest($,(0,n.signalFromNodeResponse)(t));try{let i,T=async e=>S.handle(Q,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=G.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let E=r.get("next.route");if(E){let t=`${K} ${E}`;e.setAttributes({"next.route":E,"http.route":E,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",E),i.updateName(t))}else e.updateName(`${K} ${_}`)}),o=async i=>{var s,o;let a=async({previousCacheEntry:r})=>{try{if(!B&&h&&g&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await T(i);e.fetchMetrics=H.renderOpts.fetchMetrics;let o=H.renderOpts.pendingWaitUntil;o&&E.waitUntil&&(E.waitUntil(o),o=void 0);let a=H.renderOpts.collectedTags;if(!k)return await (0,L.sendResponse)($,W,s,H.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);a&&(t[c.NEXT_CACHE_TAGS_HEADER]=a),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=c.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,E=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=c.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:E}}}}catch(t){throw(null==r?void 0:r.isStale)&&await S.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,I),t}},n=await S.handleResponse({req:e,nextConfig:D,cacheKey:y,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:F,isRoutePPREnabled:!1,isOnDemandRevalidate:h,revalidateOnlyGenerated:g,responseGenerator:a,waitUntil:E.waitUntil,isMinimalMode:B});if(!k)return null;if((null==n||null==(s=n.value)?void 0:s.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==n||null==(o=n.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});B||t.setHeader("x-nextjs-cache",h?"REVALIDATED":n.isMiss?"MISS":n.isStale?"STALE":"HIT"),w&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,p.fromNodeOutgoingHttpHeaders)(n.value.headers);return B&&k||d.delete(c.NEXT_CACHE_TAGS_HEADER),!n.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,l.getCacheControlHeader)(n.cacheControl)),await (0,L.sendResponse)($,W,new Response(n.value.body,{headers:d,status:n.value.status||200})),null};q&&P?await o(P):(i=G.getActiveScopeSpan(),await G.withPropagatedContext(e.headers,()=>G.trace(d.BaseServerSpan.handleRequest,{spanName:`${K} ${_}`,kind:s.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},o),void 0,!q))}catch(t){if(t instanceof R.NoFallbackError||await S.onRequestError(e,t,{routerKind:"App Router",routePath:x,routeType:"route",revalidateReason:(0,N.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:h})},!1,I),k)throw t;return await (0,L.sendResponse)($,W,new Response(null,{status:500})),null}}e.s(["handler",0,I,"patchFetch",0,function(){return(0,E.patchFetch)({workAsyncStorage:b,workUnitAsyncStorage:w})},"routeModule",0,S,"serverHooks",0,F,"workAsyncStorage",0,b,"workUnitAsyncStorage",0,w],29041)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1tm64be._.js.map