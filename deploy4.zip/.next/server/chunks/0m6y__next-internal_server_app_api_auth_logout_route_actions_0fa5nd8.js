module.exports=[82672,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_auth_logout_route_actions_0fa5nd8.js.map