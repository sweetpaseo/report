module.exports=[30337,(e,o,d)=>{}];

//# sourceMappingURL=0wqh_ebsite-health-report__next-internal_server_app_api_clients_route_actions_1awlksw.js.map