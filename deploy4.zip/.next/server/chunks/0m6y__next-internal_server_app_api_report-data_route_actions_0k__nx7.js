module.exports=[24558,(e,o,d)=>{}];

//# sourceMappingURL=0m6y__next-internal_server_app_api_report-data_route_actions_0k__nx7.js.map